// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("rpath check\n", stdout);
  return lionss_run_workload("rpath-check");
}
