// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("scan build"); }
int main(){
  announce();
  return lionss_run_workload("scan-build");
}
