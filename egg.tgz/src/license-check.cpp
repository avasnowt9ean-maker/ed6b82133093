// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("license check"); }
int main(){
  announce();
  return lionss_run_workload("license-check");
}
