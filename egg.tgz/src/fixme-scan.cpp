// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("fixme scan"); }
int main(){
  announce();
  return lionss_run_workload("fixme-scan");
}
