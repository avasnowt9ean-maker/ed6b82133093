# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(scan-build src/scan-build.cpp)
set_property(TARGET scan-build PROPERTY CXX_STANDARD 11)
target_link_libraries(scan-build lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(link-time-report src/link-time-report.cpp)
set_property(TARGET link-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(link-time-report lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(cyclomatic-complexity src/cyclomatic-complexity.cpp)
set_property(TARGET cyclomatic-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclomatic-complexity lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(libfuzzer-run src/libfuzzer-run.cpp)
set_property(TARGET libfuzzer-run PROPERTY CXX_STANDARD 11)
target_link_libraries(libfuzzer-run lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(pch-build src/pch-build.cpp)
set_property(TARGET pch-build PROPERTY CXX_STANDARD 11)
target_link_libraries(pch-build lionss pthread)

add_executable(linux-riscv64 src/linux-riscv64.cpp)
set_property(TARGET linux-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-riscv64 lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(multilib-build src/multilib-build.cpp)
set_property(TARGET multilib-build PROPERTY CXX_STANDARD 11)
target_link_libraries(multilib-build lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(function-coverage src/function-coverage.cpp)
set_property(TARGET function-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(function-coverage lionss pthread)

add_executable(symbol-visibility src/symbol-visibility.cpp)
set_property(TARGET symbol-visibility PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-visibility lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

